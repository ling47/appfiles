﻿// 停止播放
function stopPlay(){
 vlc.playlist.stop();
// isPlaying=0;
 document.getElementById("stop_button").style.display="none";
 document.getElementById("play_button").style.display="block";
}
//播放
function Play(){
 vlc.playlist.play();
 document.getElementById("stop_button").style.display="block";
 document.getElementById("play_button").style.display="none";
}
// 静音
function noSound(){
 document.getElementById("k_sound").style.display="block";
 document.getElementById("no_sound").style.display="none";
 if(vlc.audio.volume>=1){
  vlc.audio.volume=0;
 }
}
// 开音
function kSound(){
 document.getElementById("k_sound").style.display="none";
 document.getElementById("no_sound").style.display="block";
 if(vlc.audio.volume==0){
  vlc.audio.volume=100;
 }
}

// 音量-
function jianSound(){
 vlc.audio.volume+=-10;
 if(vlc.audio.volume<=0){
  vlc.audio.volume=0;
  alert('已经最小，不能再减!')
 }
}
// 音量+
function jiaSound(){
 vlc.audio.volume+=10;
 if(vlc.audio.volume>=200){
  vlc.audio.volume=200;
  alert('已经最大，不能再加!')
 }
}

//全屏
function fullScreen(){
  vlc.video.toggleFullscreen();
}

//重新载入
function reload(){
 location.reload();
}

