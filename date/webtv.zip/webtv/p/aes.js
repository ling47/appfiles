!
function(e, r) {
    "object" == typeof exports ? module.exports = exports = r(require("./core"), require("./enc-base64"), require("./md5"), require("./evpkdf"), require("./cipher-core")) : "function" == typeof define && define.amd ? define(["./core", "./enc-base64", "./md5", "./evpkdf", "./cipher-core"], r) : r(e.CryptoJS)
} (this,
function(i) {
    return function() {
        var e = i,
        r = e.lib.BlockCipher,
        o = e.algo,
        u = [],
        f = [],
        h = [],
        y = [],
        a = [],
        p = [],
        v = [],
        _ = [],
        k = [],
        l = []; !
        function() {
            for (var e = [], r = 0; r < 256; r++) e[r] = r < 128 ? r << 1 : r << 1 ^ 283;
            for (var o = 0,
            i = 0,
            r = 0; r < 256; r++) {
                var t = i ^ i << 1 ^ i << 2 ^ i << 3 ^ i << 4;
                u[o] = t = t >>> 8 ^ 255 & t ^ 99;
                var n = e[f[t] = o],
                c = e[n],
                s = e[c],
                d = 257 * e[t] ^ 16843008 * t;
                h[o] = d << 24 | d >>> 8,
                y[o] = d << 16 | d >>> 16,
                a[o] = d << 8 | d >>> 24,
                p[o] = d,
                v[t] = (d = 16843009 * s ^ 65537 * c ^ 257 * n ^ 16843008 * o) << 24 | d >>> 8,
                _[t] = d << 16 | d >>> 16,
                k[t] = d << 8 | d >>> 24,
                l[t] = d,
                o ? (o = n ^ e[e[e[s ^ n]]], i ^= e[e[i]]) : o = i = 1
            }
        } ();
        var S = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54],
        o = o.AES = r.extend({
            _doReset: function() {
                if (!this._nRounds || this._keyPriorReset !== this._key) {
                    for (var e = this._keyPriorReset = this._key,
                    r = e.words,
                    o = e.sigBytes / 4,
                    i = 4 * (1 + (this._nRounds = 6 + o)), t = this._keySchedule = [], n = 0; n < i; n++) n < o ? t[n] = r[n] : (d = t[n - 1], n % o ? 6 < o && n % o == 4 && (d = u[d >>> 24] << 24 | u[d >>> 16 & 255] << 16 | u[d >>> 8 & 255] << 8 | u[255 & d]) : (d = u[(d = d << 8 | d >>> 24) >>> 24] << 24 | u[d >>> 16 & 255] << 16 | u[d >>> 8 & 255] << 8 | u[255 & d], d ^= S[n / o | 0] << 24), t[n] = t[n - o] ^ d);
                    for (var c = this._invKeySchedule = [], s = 0; s < i; s++) {
                        var d, n = i - s;
                        d = s % 4 ? t[n] : t[n - 4],
                        c[s] = s < 4 || n <= 4 ? d: v[u[d >>> 24]] ^ _[u[d >>> 16 & 255]] ^ k[u[d >>> 8 & 255]] ^ l[u[255 & d]]
                    }
                }
            },
            encryptBlock: function(e, r) {
                this._doCryptBlock(e, r, this._keySchedule, h, y, a, p, u)
            },
            decryptBlock: function(e, r) {
                var o = e[r + 1];
                e[r + 1] = e[r + 3],
                e[r + 3] = o,
                this._doCryptBlock(e, r, this._invKeySchedule, v, _, k, l, f);
                o = e[r + 1];
                e[r + 1] = e[r + 3],
                e[r + 3] = o
            },
            _doCryptBlock: function(e, r, o, i, t, n, c, s) {
                for (var d = this._nRounds,
                u = e[r] ^ o[0], f = e[r + 1] ^ o[1], h = e[r + 2] ^ o[2], y = e[r + 3] ^ o[3], a = 4, p = 1; p < d; p++) var v = i[u >>> 24] ^ t[f >>> 16 & 255] ^ n[h >>> 8 & 255] ^ c[255 & y] ^ o[a++],
                _ = i[f >>> 24] ^ t[h >>> 16 & 255] ^ n[y >>> 8 & 255] ^ c[255 & u] ^ o[a++],
                k = i[h >>> 24] ^ t[y >>> 16 & 255] ^ n[u >>> 8 & 255] ^ c[255 & f] ^ o[a++],
                l = i[y >>> 24] ^ t[u >>> 16 & 255] ^ n[f >>> 8 & 255] ^ c[255 & h] ^ o[a++],
                u = v,
                f = _,
                h = k,
                y = l;
                v = (s[u >>> 24] << 24 | s[f >>> 16 & 255] << 16 | s[h >>> 8 & 255] << 8 | s[255 & y]) ^ o[a++],
                _ = (s[f >>> 24] << 24 | s[h >>> 16 & 255] << 16 | s[y >>> 8 & 255] << 8 | s[255 & u]) ^ o[a++],
                k = (s[h >>> 24] << 24 | s[y >>> 16 & 255] << 16 | s[u >>> 8 & 255] << 8 | s[255 & f]) ^ o[a++],
                l = (s[y >>> 24] << 24 | s[u >>> 16 & 255] << 16 | s[f >>> 8 & 255] << 8 | s[255 & h]) ^ o[a++];
                e[r] = v,
                e[r + 1] = _,
                e[r + 2] = k,
                e[r + 3] = l
            },
            keySize: 8
        });
        e.AES = r._createHelper(o)
    } (),
    i.AES
});